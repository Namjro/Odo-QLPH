<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLendersTable extends Migration
{
    /**
     * Run the migrations.
     *Loaner
     * @return void
     */
    public function up()
    {
//        Schema::drop('loaners');
//        Schema::drop('contacts');
//        Schema::drop('bad_debt_history');
//        Schema::drop('facebook_friends');
//        Schema::drop('facebook');
//        Schema::drop('call_logs');
//        Schema::drop('document_type');
//        Schema::drop('document_entity');
//        Schema::drop('document_entity_attribute');
//        Schema::drop('document_entity_attribute_value');
//        Schema::drop('repayments');
//        Schema::drop('receipts');
//        Schema::drop('loan_document');
//        Schema::drop('products');
//        Schema::drop('product_document_type');
//        Schema::drop('lenders');



        Schema::create('lenders', function (Blueprint $table) {
            $table->increments('id');
            $table->string('facebook_id')->unique()->comment('');
            $table->string('facebook_token')->unique()->comment('');
            $table->string('user_name')->nullable()->comment('');
            $table->string('full_name')->nullable()->comment('');
            $table->string('birthday')->nullable()->comment('');
            $table->string('email')->nullable()->comment('');
            $table->string('email_status')->nullable()->comment('');
            $table->string('password')->unique()->comment('');
            $table->string('phone')->nullable()->comment('');
            $table->string('phone_status')->nullable()->comment('');
            $table->string('full_address',500)->nullable()->comment('');
            $table->string('sex')->nullable()->comment('');
            $table->string('job')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');

            /*$table->string('permission',300)->unique();
            $table->string('permission')->nullable();
            $table->string('permission')->nullable()->comment('my comment');
            $table->string('permission')->default("12");
            $table->string('permission')->unsigned();
            $table->index(['account_id', 'created_at']);*/
            //$table->foreign('user_id')->references('id')->on('users');
            $table->timestamps();
        });

        Schema::create('lender_loans', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->unique()->comment('');
            $table->string('lender_id')->unique()->comment('');
            $table->string('amount')->nullable()->comment('so tien muon vay');
            $table->string('period')->nullable()->comment('thoi gian muon vay');
            $table->string('period_type')->nullable()->comment('ngay,thang');
            $table->string('interest_rate')->nullable()->comment('Lãi suất');
            $table->string('total_interest')->nullable()->comment('Lãi');
            $table->string('status')->nullable()->comment('0:moi,1:dang cho vay');
            $table->string('user_id')->nullable()->comment('');
            $table->string('user_name')->nullable()->comment('');
            $table->string('accepted_date')->nullable()->comment('Ngay duyet khoan vay');
            $table->string('disbursed_date')->nullable()->comment('Ngay duyet khoan vay');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('lenders');
    }
}
