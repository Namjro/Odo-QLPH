<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *Loaner
     * @return void
     */
    public function up()
    {
//        Schema::drop('loaners');
//        Schema::drop('contacts');
//        Schema::drop('bad_debt_history');
//        Schema::drop('facebook_friends');
//        Schema::drop('facebook');
//        Schema::drop('call_logs');
//        Schema::drop('document_type');
//        Schema::drop('document_entity');
//        Schema::drop('document_entity_attribute');
//        Schema::drop('document_entity_attribute_value');
//        Schema::drop('repayments');
//        Schema::drop('receipts');
//        Schema::drop('loan_document');
//        Schema::drop('products');
//        Schema::drop('product_document_type');
//        Schema::drop('lenders');



        // Hồ sơ quyết định lãi suất . tỷ lệ nợ xấu cao thì lãi suất cao

//        Schema::create('products', function (Blueprint $table) {
//            $table->increments('id');
//            $table->string('name')->nullable()->comment('');
//            $table->string('code')->nullable()->comment('');
//            $table->string('fee_rate')->nullable()->comment('');
//            $table->string('interest_rate')->nullable()->comment('');
//            $table->string('type_of_rate')->nullable()->comment('1:%/nam');
//            $table->string('max_amount')->nullable()->comment('');
//            $table->string('min_amount')->nullable()->comment('');
//            $table->string('max_duration')->nullable()->comment('');
//            $table->string('min_duration')->nullable()->comment('');
//            $table->string('type_duration')->nullable()->comment('ngay,thang');
//            $table->string('status')->nullable()->comment('1:Dangchay,2:dung');
//            $table->timestamps();
//        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('products');
    }
}
