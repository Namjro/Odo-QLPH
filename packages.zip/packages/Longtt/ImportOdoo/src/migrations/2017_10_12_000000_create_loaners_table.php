<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLoanersTable extends Migration
{
    /**
     * Run the migrations.
     *Loaner
     * @return void
     */
    public function up()
    {
//        Schema::drop('loaners');
//        Schema::drop('contacts');
//        Schema::drop('bad_debt_history');
//        Schema::drop('facebook_friends');
//        Schema::drop('facebook');
//        Schema::drop('call_logs');
//        Schema::drop('document_type');
//        Schema::drop('document_entity');
//        Schema::drop('document_entity_attribute');
//        Schema::drop('document_entity_attribute_value');
//        Schema::drop('repayments');
//        Schema::drop('receipts');
//        Schema::drop('loan_document');
//        Schema::drop('products');
//        Schema::drop('product_document_type');
//        Schema::drop('lenders');

        Schema::create('loaners', function (Blueprint $table) {
            $table->increments('id');
            $table->string('facebook_id')->unique()->comment('');
            $table->string('facebook_token')->unique()->comment('');
            $table->string('user_name')->nullable()->comment('');
            $table->string('full_name')->nullable()->comment('');
            $table->string('birthday')->nullable()->comment('');
            $table->string('email')->nullable()->comment('');
            $table->string('email_status')->nullable()->comment('');
            $table->string('password')->unique()->comment('');
            $table->string('phone')->nullable()->comment('');
            $table->string('phone_status')->nullable()->comment('');
            $table->string('full_address',500)->nullable()->comment('');
            $table->string('sex')->nullable()->comment('');
            $table->string('job')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');
            $table->string('amount_of_debt')->nullable()->comment('');

            /*$table->string('permission',300)->unique();
            $table->string('permission')->nullable();
            $table->string('permission')->nullable()->comment('my comment');
            $table->string('permission')->default("12");
            $table->string('permission')->unsigned();
            $table->index(['account_id', 'created_at']);*/
            //$table->foreign('user_id')->references('id')->on('users');
            $table->timestamps();
        });

        Schema::create('contacts', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('full_name')->nullable()->comment('');
            $table->string('phone_number')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('bad_debt_history', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('history')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('facebook_friends', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('full_name')->nullable()->comment('');
            $table->string('link_facebook')->nullable()->comment('');
            $table->string('relation')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('facebook', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('total_friend')->nullable()->comment('');
            $table->string('live_time')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('call_logs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('phone_number')->nullable()->comment('');
            $table->string('duration')->nullable()->comment('');
            $table->string('type')->nullable()->comment('');
            $table->string('time')->nullable()->comment('');
            $table->timestamps();
        });



        Schema::create('document_type', function (Blueprint $table) {
            $table->increments('id');
            $table->string('code')->unique()->comment('');
            $table->string('name')->unique()->comment('');
            //$table->string('images')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('document_entity', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->comment('');
            $table->string('document_type_id')->nullable()->comment('');
            $table->string('document_type_code')->nullable()->comment('');
            $table->string('document_type_name')->nullable()->comment('');

            $table->timestamps();
        });

        Schema::create('document_entity_attribute', function (Blueprint $table) {
            $table->increments('id');
            $table->string('code')->unique()->comment('');
            $table->string('name')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');
            $table->string('document_type_id')->nullable()->comment('');
            $table->string('document_type_code')->nullable()->comment('');
            $table->string('document_type_name')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('document_entity_attribute_value', function (Blueprint $table) {
            $table->increments('id');
            $table->string('document_entity_id')->nullable()->comment('');
            $table->string('document_entity_attribute_id')->nullable()->comment('');
            $table->string('document_entity_attribute_code')->nullable()->comment('');
            $table->string('document_entity_attribute_name')->nullable()->comment('');
            $table->string('document_type_id')->nullable()->comment('');
            $table->string('document_type_code')->nullable()->comment('');
            $table->string('document_type_name')->nullable()->comment('');

            $table->string('value')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('loans', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->unique()->comment('');
            $table->string('amount')->nullable()->comment('so tien muon vay');
            $table->string('period')->nullable()->comment('thoi gian muon vay');
            $table->string('period_type')->nullable()->comment('ngay,thang');
            $table->string('interest_rate')->nullable()->comment('Lãi suất');
            $table->string('total_interest')->nullable()->comment('Lãi');
            $table->string('status')->nullable()->comment('');
            $table->string('user_id')->nullable()->comment('');
            $table->string('user_name')->nullable()->comment('');
            $table->string('accepted_date')->nullable()->comment('Ngay duyet khoan vay');
            $table->string('disbursed_date')->nullable()->comment('Ngay duyet khoan vay');
            $table->timestamps();
        });

        Schema::create('repayments', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loan_id')->nullable()->comment('');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('repayment_period')->nullable()->comment('kỳ trả nợ');
            //$table->string('number_of_repayment_period')->nullable()->comment('tổng số kỳ trả ');
            $table->string('original_amount_remain')->nullable()->comment('tiền gốc còn lại');
            $table->string('original_amount_period')->nullable()->comment('tiền gốc phải trả');
            $table->string('interest_amount_period')->nullable()->comment('tiền lãi phải trả');
            $table->string('period_amount')->nullable()->comment('tổng gốc và lãi phải trả');
            $table->string('real_repayment_amount')->nullable()->comment('số tiền thực tế người vay trả ');
            $table->string('unpaid_amount')->nullable()->comment('số tiền chưa trả');
            $table->string('repayment_date')->nullable()->comment('ngày phải trả nợ ');
            $table->string('real_repayment_date')->nullable()->comment('ngày thuc te tra no');
            $table->string('number_out_of_date')->nullable()->comment('so ngay qua han');
            $table->string('out_of_date_amount')->nullable()->comment('so tien phat qua han');
            $table->string('number_of_grace_date')->nullable()->comment('ngay an han');
            $table->string('status')->nullable()->comment('trang thai tra no');
            $table->timestamps();
        });

        Schema::create('receipts', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->nullable()->comment('');
            $table->string('loan_id')->nullable()->comment('');
            $table->string('repayment_id')->nullable()->comment('');
            $table->string('amount')->nullable()->comment('so tien');
            //$table->string('number_of_repayment_period')->nullable()->comment('tổng số kỳ trả ');
            $table->string('payment_date')->nullable()->comment('ngay nop tien');
            $table->string('status')->nullable()->comment('');
            $table->timestamps();
        });

        Schema::create('loan_document', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loan_id')->nullable()->comment('');
            $table->string('document_entity_id')->nullable()->comment('');
            $table->timestamps();
        });

        // Hồ sơ quyết định lãi suất . tỷ lệ nợ xấu cao thì lãi suất cao

//        Schema::create('products', function (Blueprint $table) {
//            $table->increments('id');
//            $table->string('name')->nullable()->comment('');
//            $table->string('code')->nullable()->comment('');
//            $table->string('fee_rate')->nullable()->comment('');
//            $table->string('interest_rate')->nullable()->comment('');
//            $table->string('type_of_rate')->nullable()->comment('');
//            $table->string('max_amount')->nullable()->comment('');
//            $table->string('min_amount')->nullable()->comment('');
//            $table->string('max_duration')->nullable()->comment('');
//            $table->string('min_duration')->nullable()->comment('');
//            $table->string('status')->nullable()->comment('');
//            $table->timestamps();
//        });

        Schema::create('product_document_type', function (Blueprint $table) {
            $table->increments('id');
            $table->string('product_id')->nullable()->comment('');
            $table->string('document_type_id')->nullable()->comment('');
            $table->timestamps();
        });




    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('permissions');
    }
}
