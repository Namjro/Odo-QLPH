<?php
Route::group(['middleware' => ['web']], function () {
    Route::get('/vaytien','Longtt\Vaytien\Controllers\Frontend\IndexController@index');

    Route::get('loaner/index','Longtt\Vaytien\Controllers\Loaner\IndexController@index')->name('loaner.index');
    Route::get('loaner/create','Longtt\Vaytien\Controllers\Loaner\CreateController@index')->name('loaner.create');
    Route::get('loaner/edit/{id}','Longtt\Vaytien\Controllers\Loaner\EditController@index')->name('loaner.edit');
    Route::post('loaner/store','Longtt\Vaytien\Controllers\Loaner\StoreController@index');
    Route::get('loaner/search','Longtt\Vaytien\Controllers\Loaner\SearchController@index');
    Route::get('loaner/read','Longtt\Vaytien\Controllers\Loaner\ReadController@index');
    Route::post('loaner/update','Longtt\Vaytien\Controllers\Loaner\UpdateController@index');
    Route::get('loaner/delete/{id}','Longtt\Vaytien\Controllers\Loaner\DeleteController@index');


    Route::get('loan/index','Longtt\Vaytien\Controllers\Loan\IndexController@index')->name('loan.index');
    Route::get('loan/create','Longtt\Vaytien\Controllers\Loan\CreateController@index')->name('loan.create');
    Route::get('loan/edit/{id}','Longtt\Vaytien\Controllers\Loan\EditController@index')->name('loan.edit');
    Route::post('loan/store','Longtt\Vaytien\Controllers\Loan\StoreController@index');
    Route::get('loan/search','Longtt\Vaytien\Controllers\Loan\SearchController@index');
    Route::get('loan/read','Longtt\Vaytien\Controllers\Loan\ReadController@index');
    Route::post('loan/update','Longtt\Vaytien\Controllers\Loan\UpdateController@index');
    Route::get('loan/delete/{id}','Longtt\Vaytien\Controllers\Loan\DeleteController@index');


    Route::get('document_type/index','Longtt\Vaytien\Controllers\Document_type\IndexController@index')->name('document_type.index');
    Route::get('document_type/create','Longtt\Vaytien\Controllers\Document_type\CreateController@index')->name('document_type.create');
    Route::get('document_type/edit/{id}','Longtt\Vaytien\Controllers\Document_type\EditController@index')->name('document_type.edit');
    Route::post('document_type/store','Longtt\Vaytien\Controllers\Document_type\StoreController@index');
    Route::get('document_type/search','Longtt\Vaytien\Controllers\Document_type\SearchController@index');
    Route::get('document_type/read','Longtt\Vaytien\Controllers\Document_type\ReadController@index');
    Route::post('document_type/update','Longtt\Vaytien\Controllers\Document_type\UpdateController@index');
    Route::get('document_type/delete/{id}','Longtt\Vaytien\Controllers\Document_type\DeleteController@index');


    Route::get('product/index','Longtt\Vaytien\Controllers\Product\IndexController@index')->name('product.index');
    Route::get('product/create','Longtt\Vaytien\Controllers\Product\CreateController@index')->name('product.create');
    Route::get('product/edit/{id}','Longtt\Vaytien\Controllers\Product\EditController@index')->name('product.edit');
    Route::post('product/store','Longtt\Vaytien\Controllers\Product\StoreController@index');
    Route::get('product/search','Longtt\Vaytien\Controllers\Product\SearchController@index');
    Route::get('product/read','Longtt\Vaytien\Controllers\Product\ReadController@index');
    Route::post('product/update','Longtt\Vaytien\Controllers\Product\UpdateController@index');
    Route::get('product/delete/{id}','Longtt\Vaytien\Controllers\Product\DeleteController@index');

});
