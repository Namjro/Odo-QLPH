<?php
/**
 * Created by JetBrains PhpStorm.
 * User: maconline
 * Date: 9/1/17
 * Time: 2:37 PM
 * To change this template use File | Settings | File Templates.
 */

$menus=array(
    //array("id","name","url",,"route","type","parent_id","icon_code","group"),
    array(1,"Configuration","","",1,0,"","config"),
         array("","Users","config/user/index",1),
         array("","Roles","config/role/index",1),
         array("","Permissions","config/permission/index",1),

);
