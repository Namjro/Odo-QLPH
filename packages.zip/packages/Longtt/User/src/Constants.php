<?php
/**
 * Created by PhpStorm.
 * User: long
 * Date: 2/11/17
 * Time: 10:49 AM
 */

define('GUEST',0);
define('ADMIN',1);
define('USER',2);

