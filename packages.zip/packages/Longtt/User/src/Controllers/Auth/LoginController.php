<?php

namespace Longtt\User\Controllers\Auth;

use App\Http\Controllers\Controller;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;
use Facebook\Facebook;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'logout']);
    }

    public function showLoginForm()
    {
        $facebookLoginUrl=$this->redirectToProvider();
        return view('user::auth.login',
        array("facebookLoginUrl"=>$facebookLoginUrl)
        );
    }

    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return Response
     */
    public function redirectToProvider()
    {
        set_time_limit(0);
        if (!session_id()) {
            session_start();
        }
        //return Socialite::driver('facebook')->redirect();
        $fb = configFacebook();

        $helper = $fb->getRedirectLoginHelper();

        $permissions = ['email','user_managed_groups']; // Optional permissions
        $loginUrl = $helper->getLoginUrl(config('services.facebook.redirect'), $permissions);
        return $loginUrl;
        //echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return Response
     */
    public function handleProviderCallback()
    {
        //$user = Socialite::driver('facebook')->user();
        set_time_limit(0);
        if (!session_id()) {
            session_start();
        }
        $fb = configFacebook();
        $helper = $fb->getRedirectLoginHelper();

        try {
            set_time_limit(0);
            $accessToken = $helper->getAccessToken();
        } catch (FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch (FacebookSDKException $e) {
            // When validation fails or other local issues
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }

        if (!isset($accessToken)) {
            if ($helper->getError()) {
                header('HTTP/1.0 401 Unauthorized');
                echo "Error: " . $helper->getError() . "\n";
                echo "Error Code: " . $helper->getErrorCode() . "\n";
                echo "Error Reason: " . $helper->getErrorReason() . "\n";
                echo "Error Description: " . $helper->getErrorDescription() . "\n";
            } else {
                header('HTTP/1.0 400 Bad Request');
                echo 'Bad request';
            }
            exit;
        }

       /* echo '<h3>Access Token</h3>';
        var_dump($accessToken->getValue());*/

        $oAuth2Client = $fb->getOAuth2Client();

        $tokenMetadata = $oAuth2Client->debugToken($accessToken);
        /*echo '<h3>Metadata</h3>';
       echo "<pre>";
       var_dump($tokenMetadata->getExpiresAt());
       echo "</pre>";*/

        //$tokenMetadata->validateAppId(config('services.facebook.client_id')); // Replace {app-id} with your app id
        //$tokenMetadata->validateExpiration();


        if (!$accessToken->isLongLived()) {
            // Exchanges a short-lived access token for a long-lived one
            try {
                $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);


            } catch (FacebookSDKException $e) {
                echo "<p>Error getting long-lived access token: " . $helper->getMessage() . "</p>\n\n";
                exit;
            }

            /*echo '<h3>Long-lived</h3>';
            var_dump($accessToken->getValue());*/
        }

        try {
            // Returns a `Facebook\FacebookResponse` object
            $response = $fb->get('/me?fields=id,name,email', $accessToken);
        } catch(FacebookResponseException $e) {
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch(FacebookSDKException $e) {
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }
        $user = $response->getGraphUser();


        $facebook_id=$user['id'];
        $facebook_name=$user['name'];
        $email=$user['email'];
        $facebook_token=$accessToken;
        $expire_at=$tokenMetadata->getExpiresAt();
        $user_model=App::make('Longtt\User\Model\User');
        $user_model1=$user_model->query()->where('facebook_id',$facebook_id)->get()->first();

        if(!$user_model1){
            $user_model->name=$facebook_name;
            $user_model->role_id=USER;
            $user_model->account=$email;
            $user_model->email=$email;
            $password=substr(time(),0,6);
            $user_model->password=bcrypt($password);
            $user_model->facebook_id=$facebook_id;
            $user_model->facebook_token=$facebook_token;
            $user_model->facebook_token_expire_time=$expire_at;
            $user_model->avatar="https://graph.facebook.com/".$facebook_id."/picture?type=large";
            $user_model->save();
            Auth::loginUsingId($user_model->id, true);
        }else{
            $user_model1->facebook_token=$facebook_token;
            $user_model1->facebook_token_expire_time=$expire_at;
            $user_model1->save();
            Auth::loginUsingId($user_model1->id, true);
        }
        Auth::loginUsingId($user_model->id, true);
        return redirect('/')->with('status', 'Đăng Nhập Thành Công.');
    }
}
