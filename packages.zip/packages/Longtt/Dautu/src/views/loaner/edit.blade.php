@extends('user::layout.master')
<!--edit.blade.php-->
@section('css')
<!--<link href="{{getThemeUrl()}}bs3/css/custom.css" rel="stylesheet">-->
@endsection

@section('js_lib')
@endsection

@section('js_script')
@endsection


@section('content')
<!-- page start-->
<!-- page start-->
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Basic Forms
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form action="{{url('loaner/update')}}" method="post" role="form">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{ $loaner->id }}">

                        <div class="form-group">
                            <label for="exampleInputEmail1">facebook_id</label>
                            <input type="text" name="facebook_id" value="{{ $loaner->facebook_id }}"
                                   class="form-control" id="facebook_id">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">facebook_token</label>
                            <input type="text" name="facebook_token" value="{{ $loaner->facebook_token }}"
                                   class="form-control" id="facebook_token">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">user_name</label>
                            <input type="text" name="user_name" value="{{ $loaner->user_name }}" class="form-control"
                                   id="user_name">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">full_name</label>
                            <input type="text" name="full_name" value="{{ $loaner->full_name }}" class="form-control"
                                   id="full_name">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">birthday</label>
                            <input type="text" name="birthday" value="{{ $loaner->birthday }}" class="form-control"
                                   id="birthday">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">email</label>
                            <input type="text" name="email" value="{{ $loaner->email }}" class="form-control"
                                   id="email">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">email_status</label>
                            <input type="text" name="email_status" value="{{ $loaner->email_status }}"
                                   class="form-control" id="email_status">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">password</label>
                            <input type="text" name="password" value="{{ $loaner->password }}" class="form-control"
                                   id="password">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">phone</label>
                            <input type="text" name="phone" value="{{ $loaner->phone }}" class="form-control"
                                   id="phone">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">phone_status</label>
                            <input type="text" name="phone_status" value="{{ $loaner->phone_status }}"
                                   class="form-control" id="phone_status">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">full_address</label>
                            <input type="text" name="full_address" value="{{ $loaner->full_address }}"
                                   class="form-control" id="full_address">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">sex</label>
                            <input type="text" name="sex" value="{{ $loaner->sex }}" class="form-control" id="sex">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">job</label>
                            <input type="text" name="job" value="{{ $loaner->job }}" class="form-control" id="job">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">status</label>
                            <input type="text" name="status" value="{{ $loaner->status }}" class="form-control"
                                   id="status">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">amount_of_debt</label>
                            <input type="text" name="amount_of_debt" value="{{ $loaner->amount_of_debt }}"
                                   class="form-control" id="amount_of_debt">
                        </div>


                        <button type="submit" class="btn btn-info">Submit</button>
                    </form>
                </div>

            </div>
        </section>

    </div>

</div>


<!-- page end-->
</section>
</section>

@endsection
