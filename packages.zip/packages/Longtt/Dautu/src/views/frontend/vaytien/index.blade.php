<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <link rel="shortcut icon" href="images/favicon.png">

    <title>Horizontal menu page</title>

    <!--Core CSS -->
    <link href="<?php echo getUrl('/'); ?>/BucketAdmin/html/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo getUrl('/'); ?>/BucketAdmin/html/css/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo getUrl('/'); ?>/BucketAdmin/html/font-awesome//css/font-awesome.css" rel="stylesheet" />

    <!-- Custom styles for this template -->
    <link href="<?php echo getUrl('/'); ?>/BucketAdmin/html/css/style.css" rel="stylesheet">
    <link href="<?php echo getUrl('/'); ?>/BucketAdmin/html/css/style-responsive.css" rel="stylesheet" />

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]>
    <script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

<body class="full-width">

<section id="container" class="hr-menu">
<!--header start-->
<header class="header fixed-top">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle hr-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="fa fa-bars"></span>
        </button>

        <!--logo start-->
        <!--logo start-->
        <div class="brand ">
            <a href="index.html" class="logo">
                <img src="<?php echo getUrl('/'); ?>/BucketAdmin/html/images/logo.png" alt="">
            </a>
        </div>
        <!--logo end-->
        <!--logo end-->
        <div class="horizontal-menu navbar-collapse collapse ">
            <ul class="nav navbar-nav">
                <li><a href="index.html">Dashboard</a></li>
                <li class="active"><a href="#">Components</a></li>
                <li class="dropdown">
                    <a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" href="#">UI Kits <b class=" fa fa-angle-down"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="general.html">General</a></li>
                        <li><a href="buttons.html">Buttons</a></li>
                        <li><a href="typography.html">Typography</a></li>
                        <li><a href="font_awesome.html">Font Awesome</a></li>
                    </ul>
                </li>
                <li><a href="basic_table.html">Sample Menu</a></li>
                <li class="dropdown">
                    <a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" href="#">Extra <b class=" fa fa-angle-down"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="blank.html">Blank Page</a></li>
                        <li><a href="boxed_page.html">Boxed Page</a></li>
                        <li><a href="profile.html">Profile</a></li>
                        <li><a href="404.html">404 Error Page</a></li>
                        <li><a href="500.html">500 Error Page</a></li>
                    </ul>
                </li>
            </ul>

        </div>
        <div class="top-nav hr-top-nav">
            <ul class="nav pull-right top-menu">
                <li>
                    <input type="text" class="form-control search" placeholder=" Search">
                </li>
                <!-- user login dropdown start-->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <img alt="" src="<?php echo getUrl('/'); ?>/BucketAdmin/html/images/avatar1_small.jpg">
                        <span class="username">John Doe</span>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu extended logout">
                        <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                        <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
                        <li><a href="#"><i class="fa fa-bell-o"></i> Notification</a></li>
                        <li><a href="login.html"><i class="fa fa-key"></i> Log Out</a></li>
                    </ul>
                </li>
                <!-- user login dropdown end -->
            </ul>
        </div>

    </div>

</header>
<!--header end-->
<!--sidebar start-->

<!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">
<!-- page start-->




<!------>
<div class="row">
    <div class="col-lg-12">
        <!--breadcrumbs start -->
        <ul class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#">Library</a></li>
            <li class="active">Data</li>
        </ul>
        <!--breadcrumbs end -->
    </div>
</div>
<div class="row">
<div class="col-sm-12">
<section class="panel">
<header class="panel-heading">
    General Table
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                            <a href="javascript:;" class="fa fa-cog"></a>
                            <a href="javascript:;" class="fa fa-times"></a>
                         </span>
</header>
<div class="panel-body">
<table class="table  table-hover general-table">
<thead>
<tr>
    <th> Company</th>
    <th class="hidden-phone">Descrition</th>
    <th>Profit</th>
    <th>Status</th>
    <th>Progress</th>
</tr>
</thead>
<tbody>
<tr>
    <td><a href="#">Graphics</a></td>
    <td class="hidden-phone">Lorem Ipsum dorolo imit</td>
    <td>1320.00$ </td>
    <td><span class="label label-info label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">40% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            ThemeBucket
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>556.00$ </td>
    <td><span class="label label-warning label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 70%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-danger">
                <span class="sr-only">70% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            XYZ
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>13240.00$ </td>
    <td><span class="label label-success label-mini">Paid</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 55%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">55% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            BCSE
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>3455.50$ </td>
    <td><span class="label label-danger label-mini">Paid</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 90%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-info">
                <span class="sr-only">90% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td><a href="#">AVC Ltd</a></td>
    <td class="hidden-phone">Lorem Ipsum dorolo imit</td>
    <td>110.00$ </td>
    <td><span class="label label-primary label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 60%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">60% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            Themeforest
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>456.00$ </td>
    <td><span class="label label-warning label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-danger">
                <span class="sr-only">40% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>

<tr>
    <td><a href="#">Graphics</a></td>
    <td class="hidden-phone">Lorem Ipsum dorolo imit</td>
    <td>1320.00$ </td>
    <td><span class="label label-info label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">40% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            ThemeBucket
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>556.00$ </td>
    <td><span class="label label-warning label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 70%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-danger">
                <span class="sr-only">70% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            XYZ
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>13240.00$ </td>
    <td><span class="label label-success label-mini">Paid</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 55%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">55% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            BCSE
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>3455.50$ </td>
    <td><span class="label label-danger label-mini">Paid</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 90%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-info">
                <span class="sr-only">90% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td><a href="#">AVC Ltd</a></td>
    <td class="hidden-phone">Lorem Ipsum dorolo imit</td>
    <td>110.00$ </td>
    <td><span class="label label-primary label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 60%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">60% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>
<tr>
    <td>
        <a href="#">
            Themeforest
        </a>
    </td>
    <td class="hidden-phone">Lorem Ipsum dorolo</td>
    <td>456.00$ </td>
    <td><span class="label label-warning label-mini">Due</span></td>
    <td>
        <div class="progress progress-striped progress-xs">
            <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-danger">
                <span class="sr-only">40% Complete (success)</span>
            </div>
        </div>
    </td>
</tr>

</tbody>
</table>
</div>
</section>
</div>
</div>
<div class="row">
    <div class="col-sm-6">
        <section class="panel">
            <header class="panel-heading">
                Basic Table
                            <span class="tools pull-right">
                                <a href="javascript:;" class="fa fa-chevron-down"></a>
                                <a href="javascript:;" class="fa fa-cog"></a>
                                <a href="javascript:;" class="fa fa-times"></a>
                             </span>
            </header>
            <div class="panel-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                    </tbody>
                </table>
            </div>

        </section>
    </div>
    <div class="col-sm-6">
        <section class="panel">
            <header class="panel-heading">
                Striped Table
                            <span class="tools pull-right">
                                <a href="javascript:;" class="fa fa-chevron-down"></a>
                                <a href="javascript:;" class="fa fa-cog"></a>
                                <a href="javascript:;" class="fa fa-times"></a>
                             </span>
            </header>
            <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
<!-- page end-->
</section>
</section>
<!--main content end-->
<!--footer start-->
<footer class="footer-section">
    <div class="text-center">
        2014 &copy; BucketAdmin by ThemeBucket
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
</section>

<!-- Placed js at the end of the document so the pages load faster -->

<!--Core js-->
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/jquery.js"></script>
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/bs3/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/hover-dropdown.js"></script>
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/jQuery-slimScroll-1.3.0/jquery.slimscroll.js"></script>
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/jquery.nicescroll.js"></script>
<!--Easy Pie Chart-->
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/easypiechart/jquery.easypiechart.js"></script>
<!--Sparkline Chart-->
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/sparkline/jquery.sparkline.js"></script>
<!--jQuery Flot Chart-->
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/flot-chart/jquery.flot.js"></script>
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/flot-chart/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/flot-chart/jquery.flot.resize.js"></script>
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/flot-chart/jquery.flot.pie.resize.js"></script>


<!--common script init for all pages-->
<script src="<?php echo getUrl('/'); ?>/BucketAdmin/html/js/scripts.js"></script>

</body>
</html>