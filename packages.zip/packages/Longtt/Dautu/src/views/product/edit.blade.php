

@extends('user::layout.master')
<!--edit.blade.php-->
@section('css')
<!--<link href="{{getThemeUrl()}}bs3/css/custom.css" rel="stylesheet">-->
@endsection

@section('js_lib')
@endsection

@section('js_script')
@endsection


@section('content')
<!-- page start-->
<!-- page start-->
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Basic Forms
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form action="{{url('product/update')}}" method="post" role="form">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{ $product->id }}">
                                 <div class="form-group">
            <label for="exampleInputEmail1">id</label>
            <input type="text" name="id" value="{{ $product->id }}" class="form-control" id="id">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">name</label>
            <input type="text" name="name" value="{{ $product->name }}" class="form-control" id="name">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">code</label>
            <input type="text" name="code" value="{{ $product->code }}" class="form-control" id="code">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">fee_rate</label>
            <input type="text" name="fee_rate" value="{{ $product->fee_rate }}" class="form-control" id="fee_rate">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">interest_rate</label>
            <input type="text" name="interest_rate" value="{{ $product->interest_rate }}" class="form-control" id="interest_rate">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">type_of_rate</label>
            <input type="text" name="type_of_rate" value="{{ $product->type_of_rate }}" class="form-control" id="type_of_rate">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">max_amount</label>
            <input type="text" name="max_amount" value="{{ $product->max_amount }}" class="form-control" id="max_amount">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">min_amount</label>
            <input type="text" name="min_amount" value="{{ $product->min_amount }}" class="form-control" id="min_amount">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">max_duration</label>
            <input type="text" name="max_duration" value="{{ $product->max_duration }}" class="form-control" id="max_duration">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">min_duration</label>
            <input type="text" name="min_duration" value="{{ $product->min_duration }}" class="form-control" id="min_duration">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">type_duration</label>
            <input type="text" name="type_duration" value="{{ $product->type_duration }}" class="form-control" id="type_duration">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">status</label>
            <input type="text" name="status" value="{{ $product->status }}" class="form-control" id="status">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">created_at</label>
            <input type="text" name="created_at" value="{{ $product->created_at }}" class="form-control" id="created_at">
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1">updated_at</label>
            <input type="text" name="updated_at" value="{{ $product->updated_at }}" class="form-control" id="updated_at">
         </div>

                        <button type="submit" class="btn btn-info">Submit</button>
                    </form>
                </div>

            </div>
        </section>

    </div>

</div>






<!-- page end-->
</section>
</section>

@endsection
