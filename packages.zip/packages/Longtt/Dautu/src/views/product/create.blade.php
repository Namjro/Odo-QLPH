@extends('user::layout.master')
<!--create.blade.php-->
@section('css')
<!--<link href="{{getThemeUrl()}}bs3/css/custom.css" rel="stylesheet">-->
@endsection

@section('js_lib')
@endsection
@section('js_script')
@endsection


@section('content')
<!-- page start-->
<!-- page start-->
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Create Product
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form action="{{url('product/store')}}" method="post" role="form">
                        {{ csrf_field() }}

                        <div class="form-group">
                            <label for="exampleInputEmail1">name</label>
                            <input type="text" name="name" class="form-control" id="name">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">code</label>
                            <input type="text" name="code" class="form-control" id="code">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">fee_rate</label>
                            <input type="text" name="fee_rate" class="form-control" id="fee_rate">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">interest_rate</label>
                            <input type="text" name="interest_rate" class="form-control" id="interest_rate">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Đơn vị lãi suất </label>
                            <select name="type_of_rate" class="form-control">
                                <option value="1"> %/Năm</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">max_amount</label>
                            <input type="text" name="max_amount" class="form-control" id="max_amount">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">min_amount</label>
                            <input type="text" name="min_amount" class="form-control" id="min_amount">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">max_duration</label>
                            <input type="text" name="max_duration" class="form-control" id="max_duration">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">min_duration</label>
                            <input type="text" name="min_duration" class="form-control" id="min_duration">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Đơn vị thời gian vay </label>
                            <select name="type_duration" class="form-control">
                                <option value="ngay">Theo Ngày</option>
                                <option value="thang">Theo Tháng</option>

                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">status</label>
                            <select name="status" class="form-control" id="status">
                                <option value="dangchay"> Đang chạy </option>
                                <option value="dung"> Dừng </option>
                             </select>
                        </div>


                        <button type="submit" class="btn btn-info">Submit</button>
                    </form>
                </div>

            </div>
        </section>

    </div>

</div>

@endsection
