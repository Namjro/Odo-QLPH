<?php
namespace Longtt\Vaytien\Controllers\Loaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loaner;

class IndexController extends Controller
{
    public function index()
    {
        $records=Loaner::paginate(3);
        return view('vaytien::loaner.index', ['records' => $records]);
    }

}
