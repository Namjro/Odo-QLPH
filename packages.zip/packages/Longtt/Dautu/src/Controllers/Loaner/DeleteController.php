<?php
namespace Longtt\Vaytien\Controllers\Loaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loaner;


class DeleteController extends Controller
{

    public $_loaner;

    public function __construct(Loaner $loaner){
        $this->_loaner=$loaner;
    }

    public function index($id)
    {

        $this->_loaner->find($id)->delete();
        return redirect()->route(
            'loaner.index'
        )->with('status', 'Data deleted!');

    }

}
