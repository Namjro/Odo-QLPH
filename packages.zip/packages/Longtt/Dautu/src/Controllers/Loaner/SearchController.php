<?php
namespace Longtt\Vaytien\Controllers\Loaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loaner;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        $query = $request->input('q');
        if ($query)
        {
            $records = Loaner::where('id', 'LIKE', "%$query%")
                  ->orWhere('facebook_id', 'LIKE', "%$query%")
                  ->orWhere('facebook_token', 'LIKE', "%$query%")
                  ->orWhere('user_name', 'LIKE', "%$query%")
                  ->orWhere('full_name', 'LIKE', "%$query%")
                  ->orWhere('birthday', 'LIKE', "%$query%")
                  ->orWhere('email', 'LIKE', "%$query%")
                  ->orWhere('email_status', 'LIKE', "%$query%")
                  ->orWhere('password', 'LIKE', "%$query%")
                  ->orWhere('phone', 'LIKE', "%$query%")
                  ->orWhere('phone_status', 'LIKE', "%$query%")
                  ->orWhere('full_address', 'LIKE', "%$query%")
                  ->orWhere('sex', 'LIKE', "%$query%")
                  ->orWhere('job', 'LIKE', "%$query%")
                  ->orWhere('status', 'LIKE', "%$query%")
                  ->orWhere('amount_of_debt', 'LIKE', "%$query%")

            ->paginate(3);
        }
        else
        {
            $records = Loaner::orderBy('id', 'DESC')->paginate(3);
        }

        //$records=Loaner::paginate(15);
        return view('vaytien::loaner.index', ['records' => $records]);
    }

}

