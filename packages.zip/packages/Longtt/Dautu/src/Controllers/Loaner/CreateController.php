<?php
namespace Longtt\Vaytien\Controllers\Loaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loaner;


class CreateController extends Controller
{

    public function index()
    {
        $loaners=Loaner::all();
        return view('vaytien::loaner.create',["loaners"=>$loaners]);

    }

}
