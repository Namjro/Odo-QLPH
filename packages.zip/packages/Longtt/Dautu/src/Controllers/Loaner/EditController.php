<?php
namespace Longtt\Vaytien\Controllers\Loaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loaner;

class EditController extends Controller
{

    public $loaner;

    public function __construct(Loaner $loaner){
        $this->loaner=$loaner;
    }

    public function index($id)
    {


        $loaner=$this->loaner->find($id);
        return view('vaytien::loaner.edit',[
            'loaner'=>$loaner,
        ]);

    }

}

