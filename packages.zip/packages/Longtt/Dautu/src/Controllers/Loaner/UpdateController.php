<?php
namespace Longtt\Vaytien\Controllers\Loaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loaner;

class UpdateController extends Controller
{

    public $_loaner;

    public function __construct(Loaner $loaner){
        $this->_loaner=$loaner;
    }

    public function index(Request $request)
    {
        /*$this->validate($request, [
            'email' => 'required|unique:users|max:255',
        ]);*/
        $id=$request->input('id');
        $model=$this->_loaner->find($id);
        $model->facebook_id=$request->input("facebook_id");
        $model->facebook_token=$request->input("facebook_token");
        $model->user_name=$request->input("user_name");
        $model->full_name=$request->input("full_name");
        $model->birthday=$request->input("birthday");
        $model->email=$request->input("email");
        $model->email_status=$request->input("email_status");
        $model->password=$request->input("password");
        $model->phone=$request->input("phone");
        $model->phone_status=$request->input("phone_status");
        $model->full_address=$request->input("full_address");
        $model->sex=$request->input("sex");
        $model->job=$request->input("job");
        $model->status=$request->input("status");
        $model->amount_of_debt=$request->input("amount_of_debt");
        $model->save();
        return redirect()->route(
            'loaner.index'
        )->with('status', 'Data updated!');

    }

}

