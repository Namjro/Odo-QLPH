<?php
namespace Longtt\Vaytien\Controllers\Document_type;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Document_type;


class CreateController extends Controller
{

    public function index()
    {
        $document_type=Document_type::all();
        return view('vaytien::document_type.create',["document_type"=>$document_type]);

    }

}
