<?php
namespace Longtt\Vaytien\Controllers\Document_type;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Document_type;


class DeleteController extends Controller
{

    public $_document_type;

    public function __construct(Document_type $document_type){
        $this->_document_type=$document_type;
    }

    public function index($id)
    {

        $this->_document_type->find($id)->delete();
        return redirect()->route(
            'document_type.index'
        )->with('status', 'Data deleted!');

    }

}
