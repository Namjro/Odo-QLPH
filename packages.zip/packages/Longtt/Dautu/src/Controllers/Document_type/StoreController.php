<?php
namespace Longtt\Vaytien\Controllers\Document_type;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Document_type;

class StoreController extends Controller
{


    public function __construct(){
    }

    public function index(Request $request)
    {
        $this->validate($request, [
            //'name' => 'required|unique:document_type|max:255',
        ]);
        $model=new Document_type();
                $model->id=$request->input("id");
        $model->code=$request->input("code");
        $model->name=$request->input("name");
        $model->status=$request->input("status");
        $model->created_at=$request->input("created_at");
        $model->updated_at=$request->input("updated_at");

        $model->save();
        return redirect()->route(
            'document_type.index'
        )->with('status', 'Data saved!');


    }

}

