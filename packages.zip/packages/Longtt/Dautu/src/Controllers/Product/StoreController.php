<?php
namespace Longtt\Vaytien\Controllers\Product;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Product;

class StoreController extends Controller
{


    public function __construct(){
    }

    public function index(Request $request)
    {
        $this->validate($request, [
            //'name' => 'required|unique:products|max:255',
        ]);
        $model=new Product();
        $model->name=$request->input("name");
        $model->code=$request->input("code");
        $model->fee_rate=$request->input("fee_rate");
        $model->interest_rate=$request->input("interest_rate");
        $model->type_of_rate=$request->input("type_of_rate");
        $model->max_amount=$request->input("max_amount");
        $model->min_amount=$request->input("min_amount");
        $model->max_duration=$request->input("max_duration");
        $model->min_duration=$request->input("min_duration");
        $model->type_duration=$request->input("type_duration");
        $model->status=$request->input("status");
        $model->save();
        return redirect()->route(
            'product.index'
        )->with('status', 'Data saved!');


    }

}

