<?php
namespace Longtt\Vaytien\Controllers\Product;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Product;

class EditController extends Controller
{

    public $product;

    public function __construct(Product $product){
        $this->product=$product;
    }

    public function index($id)
    {


        $product=$this->product->find($id);
        return view('vaytien::product.edit',[
            'product'=>$product,
        ]);

    }

}

