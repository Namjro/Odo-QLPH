<?php
namespace Longtt\Vaytien\Controllers\Product;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Product;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        $query = $request->input('q');
        if ($query)
        {
            $records = Product::where('name', 'LIKE', "%$query%")
                     ->orWhere('id', 'LIKE', "%$query%")
         ->orWhere('name', 'LIKE', "%$query%")
         ->orWhere('code', 'LIKE', "%$query%")
         ->orWhere('fee_rate', 'LIKE', "%$query%")
         ->orWhere('interest_rate', 'LIKE', "%$query%")
         ->orWhere('type_of_rate', 'LIKE', "%$query%")
         ->orWhere('max_amount', 'LIKE', "%$query%")
         ->orWhere('min_amount', 'LIKE', "%$query%")
         ->orWhere('max_duration', 'LIKE', "%$query%")
         ->orWhere('min_duration', 'LIKE', "%$query%")
         ->orWhere('type_duration', 'LIKE', "%$query%")
         ->orWhere('status', 'LIKE', "%$query%")
         ->orWhere('created_at', 'LIKE', "%$query%")
         ->orWhere('updated_at', 'LIKE', "%$query%")

            ->paginate(3);
        }
        else
        {
            $records = Product::orderBy('id', 'DESC')->paginate(3);
        }

        //$records=Product::paginate(15);
        return view('vaytien::product.index', ['records' => $records]);
    }

}

