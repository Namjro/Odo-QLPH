<?php
namespace Longtt\Vaytien\Controllers\Product;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Product;


class CreateController extends Controller
{

    public function index()
    {
        $products=Product::all();
        return view('vaytien::product.create',["products"=>$products]);

    }

}
