<?php
namespace Longtt\Vaytien\Controllers\Loan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loan;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        $query = $request->input('q');
        if ($query)
        {
            $records = Loan::where('name', 'LIKE', "%$query%")
                     ->orWhere('id', 'LIKE', "%$query%")
         ->orWhere('loaner_id', 'LIKE', "%$query%")
         ->orWhere('amount', 'LIKE', "%$query%")
         ->orWhere('period', 'LIKE', "%$query%")
         ->orWhere('period_type', 'LIKE', "%$query%")
         ->orWhere('interest_rate', 'LIKE', "%$query%")
         ->orWhere('total_interest', 'LIKE', "%$query%")
         ->orWhere('status', 'LIKE', "%$query%")
         ->orWhere('user_id', 'LIKE', "%$query%")
         ->orWhere('user_name', 'LIKE', "%$query%")
         ->orWhere('accepted_date', 'LIKE', "%$query%")
         ->orWhere('disbursed_date', 'LIKE', "%$query%")
         ->orWhere('created_at', 'LIKE', "%$query%")
         ->orWhere('updated_at', 'LIKE', "%$query%")

            ->paginate(3);
        }
        else
        {
            $records = Loan::orderBy('id', 'DESC')->paginate(3);
        }

        //$records=Loan::paginate(15);
        return view('vaytien::loan.index', ['records' => $records]);
    }

}

