<?php
namespace Longtt\Vaytien\Controllers\Loan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loan;

class UpdateController extends Controller
{

    public $_loan;

    public function __construct(Loan $loan){
        $this->_loan=$loan;
    }

    public function index(Request $request)
    {
        /*$this->validate($request, [
            'email' => 'required|unique:users|max:255',
        ]);*/
        $id=$request->input('id');
        $model=$this->_loan->find($id);
                $model->id=$request->input("id");
        $model->loaner_id=$request->input("loaner_id");
        $model->amount=$request->input("amount");
        $model->period=$request->input("period");
        $model->period_type=$request->input("period_type");
        $model->interest_rate=$request->input("interest_rate");
        $model->total_interest=$request->input("total_interest");
        $model->status=$request->input("status");
        $model->user_id=$request->input("user_id");
        $model->user_name=$request->input("user_name");
        $model->accepted_date=$request->input("accepted_date");
        $model->disbursed_date=$request->input("disbursed_date");
        $model->created_at=$request->input("created_at");
        $model->updated_at=$request->input("updated_at");

        $model->save();
        return redirect()->route(
            'loan.index'
        )->with('status', 'Data updated!');

    }

}

