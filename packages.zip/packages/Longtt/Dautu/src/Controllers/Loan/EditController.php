<?php
namespace Longtt\Vaytien\Controllers\Loan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loan;

class EditController extends Controller
{

    public $loan;

    public function __construct(Loan $loan){
        $this->loan=$loan;
    }

    public function index($id)
    {


        $loan=$this->loan->find($id);
        return view('vaytien::loan.edit',[
            'loan'=>$loan,
        ]);

    }

}

