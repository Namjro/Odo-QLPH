<?php
namespace Longtt\Vaytien\Controllers\Loan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loan;


class DeleteController extends Controller
{

    public $_loan;

    public function __construct(Loan $loan){
        $this->_loan=$loan;
    }

    public function index($id)
    {

        $this->_loan->find($id)->delete();
        return redirect()->route(
            'loan.index'
        )->with('status', 'Data deleted!');

    }

}
