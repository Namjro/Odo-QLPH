<?php
namespace Longtt\Vaytien\Controllers\Loan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Longtt\Vaytien\Model\Loan;


class CreateController extends Controller
{

    public function index()
    {
        $loans=Loan::all();
        return view('vaytien::loan.create',["loans"=>$loans]);

    }

}
