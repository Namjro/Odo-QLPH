<?php

namespace Longtt\Dautu;

use Illuminate\Support\ServiceProvider;

class DautuServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //echo "!@3";exit;
        require __DIR__ . '/helpers.php';
        $this->loadRoutesFrom(__DIR__.'/routes.php');
        $this->loadViewsFrom(__DIR__.'/views', 'dautu');
        $this->loadMigrationsFrom(__DIR__.'/migrations');
        $this->loadTranslationsFrom(__DIR__.'/translations','dautu');
//        $this->publishes([
//            __DIR__.'/public' => public_path('vendor/vaytien'),
//        ], 'public');
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
