/media/long/New Volume/html/laravel/tools/config/app.php
them config serviceProvider cho package
them cau hinh trong composer.json
chay composer dump-autoload
1. Tạo yêu cầu vay

id
so tien
thoi gian vay
lai suat theo ngay
don vi tien te
so tien phai tra
ngay yeu cau vay
ngay hoan thien ho so
ngay duoc cho vay
ngay phai tra tien
ngay thuc te tra tien
trang thai yeu cau vay
nguoi vay
nguoi cho vay
ho so vay

2. Nguoi vay.
id
ten day du
email
sdt
facebook

cmt
anh cmt
ten tai khoan ngan hang.
so tai khoan ngan hang
ten ngan hang
chi nhanh ngan hang

3. Nguoi cho vay
id
ten day du
email
sdt
facebook




