<?php
///**
// * Created by PhpStorm.
// * User: long
// * Date: 4/11/17
// * Time: 5:17 PM
// */
//
//function getUrl($route){
//
//    if(isset($_SERVER["HTTP_X_FORWARDED_PROTO"])){
//        return ($_SERVER["HTTP_X_FORWARDED_PROTO"]=="https") ? secure_url($route) :url($route);
//
//    }else{
//        return url($route);
//    }
//}
//
//function getThemeUrl(){
//
//    if(isset($_SERVER["HTTP_X_FORWARDED_PROTO"])){
//        return ($_SERVER["HTTP_X_FORWARDED_PROTO"]=="https") ? secure_url('/')."/BucketAdmin/html/" :url('/')."/BucketAdmin/html/";
//
//    }else{
//        return url('/')."/BucketAdmin/html/";
//    }
//}
//function getProtocol(){
//    if(isset($_SERVER["HTTP_X_FORWARDED_PROTO"])){
//        return ($_SERVER["HTTP_X_FORWARDED_PROTO"]=="https") ? "https" :'http';
//
//    }else{
//        return "http";
//    }
//
//}
//
//function set_active($path, $active = 'active') {
//
//   // \Illuminate\Support\Facades\Request;
//    return call_user_func_array('Request::is', (array)$path) ? $active : '';
//
//}