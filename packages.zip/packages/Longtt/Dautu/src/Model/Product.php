<?php
/**
 * Created by PhpStorm.
 * vaytien: long
 * Date: 2/7/17
 * Time: 4:23 PM
 */
namespace Longtt\Vaytien\Model;

use Illuminate\Database\Eloquent\Model;

class Product extends Model {

    public function document_types()
    {
        return $this->belongsToMany('Model/Document_type','product_document_type','product_id','document_type_id');
    }
}