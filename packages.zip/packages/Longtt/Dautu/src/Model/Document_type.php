<?php
/**
 * Created by PhpStorm.
 * vaytien: long
 * Date: 2/7/17
 * Time: 4:23 PM
 */
namespace Longtt\Vaytien\Model;

use Illuminate\Database\Eloquent\Model;

class Document_type extends Model {

    public $table='document_type';
}