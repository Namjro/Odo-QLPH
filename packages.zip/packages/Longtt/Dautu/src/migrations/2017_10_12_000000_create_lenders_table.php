<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLendersTable extends Migration
{
    /**
     * Run the migrations.
     *Loaner
     * @return void
     */
    public function up()
    {
//        Schema::drop('loaners');
//        Schema::drop('contacts');
//        Schema::drop('bad_debt_history');
//        Schema::drop('facebook_friends');
//        Schema::drop('facebook');
//        Schema::drop('call_logs');
//        Schema::drop('document_type');
//        Schema::drop('document_entity');
//        Schema::drop('document_entity_attribute');
//        Schema::drop('document_entity_attribute_value');
//        Schema::drop('repayments');
//        Schema::drop('receipts');
//        Schema::drop('loan_document');
//        Schema::drop('products');
//        Schema::drop('product_document_type');
//        Schema::drop('lenders');



        Schema::create('lenders', function (Blueprint $table) {
            $table->increments('id');
            $table->string('facebook_id')->unique()->comment('');
            $table->string('facebook_token')->unique()->comment('');
            $table->string('user_name')->nullable()->comment('');
            $table->string('full_name')->nullable()->comment('');
            $table->string('birthday')->nullable()->comment('');
            $table->string('email')->nullable()->comment('');
            $table->string('email_status')->nullable()->comment('');
            $table->string('password')->nullable()->comment('');
            $table->string('phone')->nullable()->comment('');
            $table->string('phone_status')->nullable()->comment('');
            $table->string('full_address',500)->nullable()->comment('');
            $table->string('sex')->nullable()->comment('');
            $table->string('job')->nullable()->comment('');
            $table->string('status')->nullable()->comment('');

            /*$table->string('permission',300)->unique();
            $table->string('permission')->nullable();
            $table->string('permission')->nullable()->comment('my comment');
            $table->string('permission')->default("12");
            $table->string('permission')->unsigned();
            $table->index(['account_id', 'created_at']);*/
            //$table->foreign('user_id')->references('id')->on('users');
            $table->timestamps();
        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('lenders');
    }
}
