<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLenderLoansTable extends Migration
{
    /**
     * Run the migrations.
     *Loaner
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('lenders_loans')) {
            Schema::drop('lenders_loans');
        }
        Schema::create('lender_loans', function (Blueprint $table) {
            $table->increments('id');
            $table->string('loaner_id')->unique()->comment('');
            $table->string('lender_id')->unique()->comment('');
            $table->string('loan_id')->unique()->comment('');
            $table->string('amount')->nullable()->comment('so tien muon vay');
            $table->string('period')->nullable()->comment('thoi gian muon vay');
            $table->string('period_type')->nullable()->comment('ngay,thang');
            $table->string('interest_rate')->nullable()->comment('Lãi suất');
            $table->string('total_interest')->nullable()->comment('Lãi');
            $table->string('status')->nullable()->comment('0:moi,1:dang cho vay');
            $table->string('user_id')->nullable()->comment('');
            $table->string('user_name')->nullable()->comment('');
            $table->string('accepted_date')->nullable()->comment('Ngay duyet khoan vay');
            $table->string('disbursed_date')->nullable()->comment('Ngay duyet khoan vay');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('lender_loans');
    }
}
